/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.bbbaden.login;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author Eleasar
 */
@Named(value="ranglisteBean")
@SessionScoped
public class ranglisteBean implements Serializable {

    private List<String[]> ranklist;

    public ranglisteBean() {
        ranklist = new ArrayList<>();
    }

    public List<String[]> getRanklist() {
        return ranklist;
    }

    public List<String[]> readRanklist() {
    List<String[]> ranklist = new ArrayList<>();
    try {
        InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream("resources/ranklist.txt");
        BufferedReader br = new BufferedReader(new InputStreamReader(input, "UTF-8"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(";");
            ranklist.add(values);
        }
        br.close();
    } catch (IOException e) {
    }
    return ranklist;
}
}
