/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.bbbaden.login;

import com.sun.xml.internal.ws.client.RequestContext;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Named;

/**
 *
 * @author Eleasar
 */
@Named(value="gameBean")
@SessionScoped
public class gameBean implements Serializable {
    private int lebenspunkte = 4;
    private int kontostand = 50;
    private List<String> saetze;
    private String satz;
    
    public int getLebenspunkte() {
        return lebenspunkte;
    }
    
    public int getKontostand() {
        return kontostand;
    }
    
    public void removeLebenspunkte(int abzug) {
        lebenspunkte -= abzug;
    }
    
    public void addMoney(int money) {
        kontostand += money;
    }
    
    public void readSaetze() {
    List<String> saetze = new ArrayList<>();
    try {
        InputStream is = FacesContext.getCurrentInstance().getExternalContext()
                .getResourceAsStream("/resources/saetze.txt");
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String line;
        while ((line = br.readLine()) != null) {
            saetze.add(line);
        }
        br.close();
    } catch (IOException e) {
    }
    this.saetze = saetze;
}
    
    public String generateSatz() {
        readSaetze();
        if (saetze.isEmpty()) {
            return null;
        }
        String satz = saetze.get(new Random().nextInt(saetze.size()));
        if (satz.length() < 3) {
            return null;
        }
        List<Integer> indices = new ArrayList<>();
        while (indices.size() < 3) {
            int index = new Random().nextInt(satz.length());
            if (!indices.contains(index)) {
                indices.add(index);
            }
        }
        char[] satzChars = satz.toCharArray();
        for (int index : indices) {
            char c = satzChars[index];
            for (int i = 0; i < satzChars.length; i++) {
                if (satzChars[i] == c) {
                    satzChars[i] = '*';
                }
            }
        }
        return new String(satzChars);
    }
    public void checkBuchstabe(String buchstabe) {
        if(satz.contains(buchstabe)) {
            System.out.println("Der Buchstabe '" + buchstabe + "' ist im Satz enthalten.");
        } else {
            System.out.println("Der Buchstabe '" + buchstabe + "' ist im Satz nicht enthalten.");
        }
    }
   
    

    
}
